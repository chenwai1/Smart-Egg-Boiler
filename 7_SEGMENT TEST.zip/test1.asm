ORG 0000H

LJMP MAIN

ORG 0030H

SER     BIT 84H      ; P0.4
SRCLK   BIT 85H      ; P0.5
RCLK    BIT 86H      ; P0.6

MAIN:

    MOV A,#00H
    ACALL SHIFT_OUT

    MOV A,#01H
    ACALL SHIFT_OUT

HERE:
    SJMP HERE

;====================================
SHIFT_OUT:

    MOV R0,#8

LOOP1:

    MOV C,ACC.7
    MOV SER,C

    CLR SRCLK
    NOP
    SETB SRCLK

    RL A

    DJNZ R0,LOOP1

    CLR RCLK
    NOP
    SETB RCLK

    RET
