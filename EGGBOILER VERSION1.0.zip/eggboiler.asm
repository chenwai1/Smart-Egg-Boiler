;=============================================================================
; SMART EGG BOILER - CORE MINIMALIST VERSION
;=============================================================================
; FEATURES ENABLED: Mode Selection, Heating, DHT11 Humidity, Cooking, Abort (SW2)
; FEATURES REMOVED: 7-Segment, Buzzer, Countdown Timers, Completion Alerts
;=============================================================================
; PIN ASSIGNMENTS:
; P1.0-P1.7 : ADC0804 Data Input (DB0-DB7)
; P2.0      : DHT11 Data (Requires 10k Pull-up)
; P2.1      : Grove Vibration Sensor
; P2.2      : SW1 (Select/Confirm)
; P2.3      : SW2 (Stop/Abort)
; P2.4      : Relay Module
; P2.6      : Red LED (Active Low)
; P2.7      : Green LED (Active Low)
; P3.0/P3.1 : LCD I2C SDA/SCL
; P3.4      : ADC0804 INTR (Pin 5) - Interrupt Input
; P3.5/6/7  : ADC0804 WR / RD / CS
;=============================================================================

DHT_DATA    EQU P2.0        
VIBRATION   EQU P2.1        
BUTTON_SW1  EQU P2.2        
BUTTON_SW2  EQU P2.3        
RELAY       EQU P2.4        
LED_RED     EQU P2.6        
LED_GREEN   EQU P2.7        

I2C_SDA     EQU P3.0        
I2C_SCL     EQU P3.1  
ADC_INTR    EQU P3.4        ; ADC Pin 5	
ADC_WR      EQU P3.5        
ADC_RD      EQU P3.6        
ADC_CS      EQU P3.7        

MODE        EQU 30H         
ADC_VAL     EQU 31H         
HUM_VAL     EQU 33H         
LCD_BYTE    EQU 37H         

;=============================================================================
; MAIN SYSTEM BOOT
;=============================================================================
        ORG 0000H
        LJMP MAIN
        
        ORG 0030H

MAIN:
        CALL INIT_SYSTEM
        CALL LCD_INIT

;=============================================================================
; STATE 1: MODE SELECTION
;=============================================================================
MENU_LOOP:
        CALL READ_ADC
        CALL EVALUATE_MODE
        CALL UPDATE_LCD_MENU
        
        JNB  BUTTON_SW1, CONFIRM_MODE
        SJMP MENU_LOOP

CONFIRM_MODE:
        CALL DEBOUNCE_SW1
        CALL LCD_CLEAR
        MOV  DPTR, #STR_CONFIRM
        CALL LCD_PRINT_LINE1
        CALL DELAY_500MS
        SJMP HEATING_PHASE

;=============================================================================
; STATE 2: HEATING PHASE & HUMIDITY DETECTION
;=============================================================================
HEATING_PHASE:
        CALL LCD_CLEAR
        MOV  DPTR, #STR_HEATING
        CALL LCD_PRINT_LINE1
        
        CLR  LED_RED             ; Turn ON Red LED (Active Low)
        SETB LED_GREEN           ; Ensure Green is OFF
        SETB RELAY               ; Turn ON Heater

HEAT_LOOP:
		JNB  BUTTON_SW2, DO_ABORT ; 1. Check Emergency Stop
        CALL READ_DHT11           ; 2. Read Humidity
        CALL DISPLAY_HUMIDITY     ; 3. Display Humidity on LCD Line 2
        JNB   VIBRATION, HEAT_WAIT ; 4. Check Vibration (Logic 1 = No vibration)
        
        MOV  A, HUM_VAL           ; 5. Vibration detected, check Humidity
        CJNE A, #46H, CHK_THRESH  ; Compare with 50H (70% Decimal) C=1 when A<70H, C=0 when A>70H
        SJMP COOKING_PHASE        ; Exact match
CHK_THRESH:
        JNC  COOKING_PHASE        ; Humidity > 70%, move to cooking

HEAT_WAIT:
        CALL DELAY_500MS          ; Wait before next reading
        CALL DELAY_500MS
        SJMP HEAT_LOOP

DO_ABORT:
        LJMP ABORT_PROCESS

;=============================================================================
; STATE 3: COOKING PHASE
;=============================================================================
COOKING_PHASE:
        CALL LCD_CLEAR
        MOV  DPTR, #STR_COOKING
        CALL LCD_PRINT_LINE1
        MOV  DPTR, #STR_BLANK     ; Clear the humidity line
        CALL LCD_PRINT_LINE2

COOK_LOOP:
        JNB  BUTTON_SW2, DO_ABORT ; Check Emergency Stop
        
        ; The system will stay here infinitely until SW2 is pressed.
        ; Timers and logic will be added here in the future.
        CALL DELAY_20MS
        SJMP COOK_LOOP

;=============================================================================
; ABORT ROUTINE
;=============================================================================
ABORT_PROCESS:
        MOV  SP, #07H            ; Clear stack pointer *since there are too many stacks after running the code, 
		;this sp tells the cpu to stack from 08H, WHILE 09H AND MORE DATA DIDNT GET COVERED
        CLR  RELAY               ; Turn OFF Heater
        SETB LED_RED             ; Turn OFF Red LED
        
        CALL LCD_CLEAR
        MOV  DPTR, #STR_STOPPED
        CALL LCD_PRINT_LINE1
        
        CALL DELAY_500MS
        LJMP MAIN

;=============================================================================
; ADC0804 DRIVER (DELAY BASED - NO INTERRUPTS)
;=============================================================================
READ_ADC:

        MOV P1,#0FFH

        CLR ADC_CS
        CLR ADC_WR
        NOP
        SETB ADC_WR

        MOV R6,#100

WAIT_ADC:
        JNB ADC_INTR,ADC_READY
        DJNZ R6,WAIT_ADC

        SETB ADC_CS
        RET

ADC_READY:
        CLR ADC_RD
        MOV A,P1
        MOV ADC_VAL,A
        SETB ADC_RD
        SETB ADC_CS
        RET

EVALUATE_MODE:
        MOV  A, ADC_VAL
        CJNE A, #55H, EV_M1
        SJMP ST_S
EV_M1:  JC   ST_S
        CJNE A, #90H, EV_M2
        SJMP ST_M
EV_M2:  JC   ST_M
        SJMP ST_H
ST_S:   MOV MODE, #01H; 
		RET
ST_M:   MOV MODE, #02H; 
		RET
ST_H:   MOV MODE, #03H; 
		RET

UPDATE_LCD_MENU:
        MOV  A, MODE
        CJNE A, #01H, CH_M2
        MOV  DPTR, #STR_SOFT;string str_soft move to dptr
        CALL LCD_PRINT_LINE1
        SJMP MENU_BOT
CH_M2:  CJNE A, #02H, SET_H2
        MOV  DPTR, #STR_MED
        CALL LCD_PRINT_LINE1
        SJMP MENU_BOT
SET_H2: MOV  DPTR, #STR_HARD
        CALL LCD_PRINT_LINE1
MENU_BOT:
        RET

;=============================================================================
; DHT11 DRIVER 
;=============================================================================
READ_DHT11:

        CLR  DHT_DATA
        CALL DELAY_20MS
        SETB DHT_DATA
		CALL DELAY_40US
		
        MOV R6,#255
		
W_ST:   JNB  DHT_DATA, DHT_ALV; if 1, means no answer, move to next line
		DJNZ R6,W_ST

		RET

DHT_ALV:
		MOV R6,#255

WAIT_LOW_END:
        JB DHT_DATA,LOW_DONE
        DJNZ R6,WAIT_LOW_END
        RET

LOW_DONE:
        MOV R6,#255

WAIT_HIGH_END:
        JNB DHT_DATA,HIGH_DONE
        DJNZ R6,WAIT_HIGH_END
        RET

HIGH_DONE:
        CALL READ_BYTE; Humidity Integer
		MOV HUM_VAL, A
        CALL READ_BYTE; Humidity Decimal
        CALL READ_BYTE; Temperature Integer
        CALL READ_BYTE; Temperature Decimal
        CALL READ_BYTE; Checksum
        RET

READ_BYTE:
        MOV  R2, #08H
        MOV  A, #00H
R_BIT:  JNB  DHT_DATA, $ ;wait 50us low 26us high for 0, 50us low 70us high for 1
        CALL DELAY_40US
        MOV  C, DHT_DATA ; data put into carry
        RLC  A 
        JB   DHT_DATA, $ ; wait til dht goes back to low
        DJNZ R2, R_BIT ;read 8 bits, decrease 8 times
        RET

;=============================================================================
; LCD I2C DRIVERS & DISPLAY SUBROUTINES
;=============================================================================
DISPLAY_HUMIDITY:
        MOV  A, #0C0H            ; Move cursor to Line 2
        CALL LCD_CMD
        MOV  DPTR, #STR_HUM
        CALL LCD_STRING
        
        MOV  A, HUM_VAL
        MOV  B, #0AH
        DIV  AB
        ADD  A, #30H
		CALL LCD_DATA ;display tens place
        MOV  A, B
        ADD  A, #30H
		CALL LCD_DATA; display ones place
       
        MOV  A, #'%'; 
		CALL LCD_DATA
        MOV  A, #' '; for the case 100% becomes 99%
		CALL LCD_DATA
        MOV  A, #' '; 
		CALL LCD_DATA
        RET

LCD_INIT:
        CALL DELAY_20MS
        MOV  A, #30H; 
		CALL LCD_RST; 
		CALL DELAY_2MS
        MOV  A, #30H; 
		CALL LCD_RST; 
		CALL DELAY_2MS
        MOV  A, #30H; 
		CALL LCD_RST
        MOV  A, #20H; 
		CALL LCD_RST
        MOV  A, #28H; 
		CALL LCD_CMD
        MOV  A, #0CH; 
		CALL LCD_CMD
        MOV  A, #06H; 
		CALL LCD_CMD
        MOV  A, #01H; 
		CALL LCD_CMD
        CALL DELAY_20MS
        RET

LCD_CLEAR:       
		MOV A, #01H; 
		CALL LCD_CMD; 
		CALL DELAY_20MS; 
		RET
		
LCD_PRINT_LINE1: 
		MOV A, #80H; 
		CALL LCD_CMD; 
		CALL LCD_STRING; 
		RET
		
LCD_PRINT_LINE2: MOV A, #0C0H; CALL LCD_CMD; CALL LCD_STRING; RET

LCD_STRING:      
		CLR A; start from 0
		MOVC A, @A+DPTR; dptr is used for alphabets and symbols in this case
		JZ L_END; check if the value in the address is 0, 0 then jump to l_end and return
		CALL LCD_DATA; 
		INC DPTR; 
		SJMP LCD_STRING
		L_END:           
		RET

LCD_CMD:;give order         
		MOV LCD_BYTE, A; 80H
		ANL A, #0F0H; high 4 bit is involeved in comparison with #80H as #0FFH is 1111 0000 *becomes 1000 0000B
		ORL A, #08H; becomes 88H *juz to distinguish between command/output..
		CALL LCD_WR; 
		MOV A, LCD_BYTE; 
		SWAP A; 
		ANL A, #0F0H; 
		ORL A, #08H; LCD is 4bit mode so need to send twice
		CALL LCD_WR; 
		RET
		
LCD_DATA:;give data
		MOV LCD_BYTE, A; 00H
		ANL A, #0F0H; 
		ORL A, #09H; 
		CALL LCD_WR; 
		MOV A, LCD_BYTE; 
		SWAP A; 
		ANL A, #0F0H; 
		ORL A, #09H; 
		CALL LCD_WR; 
		RET

;RS 0 MEANS COMMAND
LCD_WR:          
		MOV R4, A; R4 becomes 88H
		CALL I2C_START; 
		MOV A, #4EH; PCF8574 I2C Address * wanna talk with lcd I2C module * 
		CALL I2C_SEND; 
		MOV A, R4; A back to original value
		ORL A, #04H; A becomes 08CH=1000 1100B when A=88H at previous steps *data is 1000, while 1100 is BL,EN,RW,RS respectively - 4 bit lcd is used*
		CALL I2C_SEND; 
		CALL DELAY_5US; 
		MOV A, R4; Back to original value
		ANL A, #0FBH; A becomes 88H=1000 1000B when A=88H at previous steps *data is 1000, while 1100 is BL,EN,RW,RS respectively - 4 bit lcd is used*
		CALL I2C_SEND; 
		CALL DELAY_2MS; 
		CALL I2C_STOP; 
		RET
		
LCD_RST:         
		ANL A, #0F0H; 
		ORL A, #08H; 
		CALL LCD_WR; 
		RET

I2C_START:      
		SETB I2C_SDA; 
		SETB I2C_SCL; 
		CALL DELAY_5US; 
		CLR I2C_SDA; 
		CALL DELAY_5US; 
		CLR I2C_SCL; 
		RET
		
I2C_STOP:        
		CLR I2C_SDA; 
		SETB I2C_SCL; 
		CALL DELAY_5US; 
		SETB I2C_SDA; 
		CALL DELAY_5US; 
		RET

I2C_SEND:        
		MOV R3, #08H; If A is 08CH = 1000 1100B
		
		I2C_LP: RLC A; bit7 move to C, and the original value in C will move to bit0, so it becomes 0001 1000B = 18H
		MOV I2C_SDA, C; 1 *the loop will cause the sequence of C becomes 1 0 0 0 1 1 0 0, which is same as 8CH
		SETB I2C_SCL; 1
		CALL DELAY_5US; 
		CLR I2C_SCL; complete 1 bit
		DJNZ R3, I2C_LP; decrease 1 from R3, loop until become 0
		SETB I2C_SDA; 
		SETB I2C_SCL; 
		CALL DELAY_5US; 
		CLR I2C_SCL; 
		RET

;=============================================================================
; SYSTEM UTILITIES & DELAYS
;=============================================================================
INIT_SYSTEM:
        SETB DHT_DATA; 
		SETB VIBRATION; 
		SETB BUTTON_SW1; 
		SETB BUTTON_SW2
        CLR  RELAY; 
		SETB LED_RED; 
		SETB LED_GREEN
		
        SETB I2C_SDA; 
		SETB I2C_SCL; 
		SETB ADC_CS; 
		SETB ADC_RD; 
		SETB ADC_WR
		
        MOV  P1, #0FFH
        RET

DEBOUNCE_SW1:
        CALL DELAY_20MS
        JNB  BUTTON_SW1, $
        CALL DELAY_20MS
        RET

DELAY_5US:   
		NOP; 
		NOP; 
		RET
		
DELAY_40US:
        MOV R7,#18
D40:
        DJNZ R7,D40
        RET
		
DELAY_2MS:   
		MOV R6, #0AH; 
		D2_L: MOV R7, #0FFH; 
		DJNZ R7, $; 
		DJNZ R6, D2_L; 
		RET
		
DELAY_20MS:  MOV R5, #14H; 
		D20_L: CALL DELAY_2MS; 
		DJNZ R5, D20_L; 
		RET
		
DELAY_500MS: MOV R4, #19H; 
		D500_L: CALL DELAY_20MS; 
		DJNZ R4, D500_L; 
		RET
		
DELAY_1S:    
		MOV R3, #32H; 
		D1S_L: CALL DELAY_20MS; 
		DJNZ R3, D1S_L; 
		RET
		
DELAY_2S:    
		CALL DELAY_1S; 
		CALL DELAY_1S; 
		RET

;=============================================================================
; STRINGS
;=============================================================================
STR_SOFT:    DB '> SOFT  BOILED ', 0 ; if no '', db 0 means address 00H
STR_MED:     DB '> MEDIUM BOILED', 0
STR_HARD:    DB '> HARD  BOILED ', 0
STR_PRESS:   DB 'Press SW1 Set   ', 0
STR_CONFIRM: DB 'Mode Confirmed! ', 0
STR_HEATING: DB 'Heating...      ', 0
STR_HUM:     DB 'Hum: ', 0
STR_COOKING: DB 'Cooking...      ', 0
STR_BLANK:   DB '                ', 0
STR_STOPPED: DB 'Process Stopped!', 0

        END
