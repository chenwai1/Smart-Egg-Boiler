;=============================================================================
; TEST: COUNTDOWN + GREEN LED + BUZZER (v3 - FULLY FIXED)
;=============================================================================
; FIXES IN THIS VERSION:
; 1. SHIFT_OUT: uses RLC A (correct MSB-first bit order)
; 2. MUX_CNT:  uses RAM 48H (avoids R5 conflict with DELAY_20MS)
; 3. SEG_BYTE: saves lookup result before SHIFT_OUT destroys A
; 4. SHOW_Dx:  DPTR reset every call (avoids stale pointer)
; 5. DELAY_2MS inside SHOW_Dx replaced with inline NOPs (avoids R6/R7 conflict)
; 6. Countdown logic: display BEFORE decrement so 0005 shows correctly
;=============================================================================
; PIN ASSIGNMENTS:
; P0.0-P0.3 : Digit select D1-D4 (NPN transistor, active LOW)
; P0.4      : SER   ? 74HC595 pin 14
; P0.5      : SRCLK ? 74HC595 pin 11
; P0.6      : RCLK  ? 74HC595 pin 12
; P2.5      : Passive Buzzer
; P2.6      : Red  LED (active LOW)
; P2.7      : Green LED (active LOW)
;=============================================================================

;-----------------------------------------------------------------------------
; BIT DEFINITIONS
;-----------------------------------------------------------------------------
DIGIT1      BIT P0.0
DIGIT2      BIT P0.1
DIGIT3      BIT P0.2
DIGIT4      BIT P0.3
SER         BIT P0.4
SRCLK       BIT P0.5
RCLK        BIT P0.6

BUZZER      EQU P2.5
LED_RED     EQU P2.6        ; Active LOW: CLR = ON, SETB = OFF
LED_GREEN   EQU P2.7        ; Active LOW: CLR = ON, SETB = OFF

;-----------------------------------------------------------------------------
; RAM VARIABLES (30H-4FH safe internal RAM)
;-----------------------------------------------------------------------------
DIG1        EQU 42H         ; MM tens digit value (0-9)
DIG2        EQU 43H         ; MM ones digit value (0-9)
DIG3        EQU 44H         ; SS tens digit value (0-9)
DIG4        EQU 45H         ; SS ones digit value (0-9)
TIME_MIN    EQU 46H         ; Countdown minutes remaining
TIME_SEC    EQU 47H         ; Countdown seconds remaining
MUX_CNT     EQU 48H         ; Mux loop counter � RAM to avoid R5 conflict
SEG_BYTE    EQU 49H         ; Segment byte temp � save before SHIFT_OUT

;=============================================================================
; RESET VECTOR
;=============================================================================
        ORG 0000H
        LJMP MAIN

        ORG 0030H

;=============================================================================
; MAIN
;=============================================================================
MAIN:
        ; Init all outputs to safe state
        SETB LED_RED            ; Red LED OFF
        SETB LED_GREEN          ; Green LED OFF
        CLR  BUZZER             ; Buzzer OFF
        SETB DIGIT1             ; All digit selects OFF (active low)
        SETB DIGIT2
        SETB DIGIT3
        SETB DIGIT4

        ; -----------------------------------------------
        ; SET YOUR TEST TIME HERE:
        ;   0 min 05 sec ? shows 00:05
        ;   1 min 00 sec ? shows 01:00
        ;   6 min 00 sec ? shows 06:00
        ; -----------------------------------------------
        MOV  TIME_MIN, #00H
        MOV  TIME_SEC, #10H

        ; Red LED ON = counting down
        CLR  LED_RED

;=============================================================================
; STATE 1: COUNTDOWN
;=============================================================================
COUNTDOWN:

    CALL WAIT_1S

    MOV A,TIME_MIN
    JNZ NOT_DONE

    MOV A,TIME_SEC
    JZ COUNT_DONE

NOT_DONE:

    MOV A,TIME_SEC
    JZ DEC_MIN

    DEC TIME_SEC
    SJMP COUNTDOWN

DEC_MIN:

    DEC TIME_MIN
    MOV TIME_SEC,#59

    SJMP COUNTDOWN

;=============================================================================
; STATE 2: COUNTDOWN DONE
;=============================================================================
COUNT_DONE:

    MOV TIME_MIN,#00H
    MOV TIME_SEC,#00H

    SETB LED_RED
    CLR  LED_GREEN

    CALL PLAY_MELODY
    CALL PLAY_MELODY

DONE_HOLD:

    CALL UPDATE_7SEG

    SJMP DONE_HOLD

;=============================================================================
; UPDATE_7SEG
; Splits TIME_MIN/TIME_SEC into 4 single digits, then multiplexes display
;
; Register usage: A, B only
; Loop counter: MUX_CNT (RAM 48H) � NOT R5 which is used by DELAY_20MS
;=============================================================================
UPDATE_7SEG:
        ; --- Split minutes into tens and ones ---
        MOV  A, TIME_MIN
        MOV  B, #0AH
        DIV  AB                 ; A = tens, B = ones
        MOV  DIG1, A
        MOV  DIG2, B

        ; --- Split seconds into tens and ones ---
        MOV  A, TIME_SEC
        MOV  B, #0AH
        DIV  AB                 ; A = tens, B = ones
        MOV  DIG3, A
        MOV  DIG4, B

        ; --- Multiplex 8 passes for brightness ---
        MOV  MUX_CNT, #08H
MUX_LOOP:
        CALL SHOW_D1
        CALL SHOW_D2
        CALL SHOW_D3
        CALL SHOW_D4
        DJNZ MUX_CNT, MUX_LOOP
        RET

;=============================================================================
; SHOW_Dx subroutines
;
; Each subroutine:
; 1. Resets DPTR to SEG_TABLE (critical � must do every call)
; 2. Looks up segment byte for the digit value
; 3. Saves to SEG_BYTE RAM (because SHIFT_OUT destroys A via RLC)
; 4. Reloads A and calls SHIFT_OUT
; 5. Enables digit pin (CLR), waits, disables (SETB)
;
; IMPORTANT: digit-on delay uses inline NOP loop (not DELAY_2MS)
;            because DELAY_2MS uses R6/R7 which may conflict
;=============================================================================
SHOW_D1:
        MOV  DPTR, #SEG_TABLE
        MOV  A, DIG1
        MOVC A, @A+DPTR
        MOV  SEG_BYTE, A
        MOV  A, SEG_BYTE
        CALL SHIFT_OUT
        CLR  DIGIT1
        CALL DIG_DELAY
        SETB DIGIT1
        RET

SHOW_D2:
        MOV  DPTR, #SEG_TABLE
		MOV A,DIG2
		MOVC A,@A+DPTR

		ORL A,#80H

        MOV  SEG_BYTE, A
        MOV  A, SEG_BYTE
        CALL SHIFT_OUT
        CLR  DIGIT2
        CALL DIG_DELAY
        SETB DIGIT2
        RET

SHOW_D3:
        MOV  DPTR, #SEG_TABLE
        MOV  A, DIG3
        MOVC A, @A+DPTR
        MOV  SEG_BYTE, A
        MOV  A, SEG_BYTE
        CALL SHIFT_OUT
        CLR  DIGIT3
        CALL DIG_DELAY
        SETB DIGIT3
        RET

SHOW_D4:
        MOV  DPTR, #SEG_TABLE
        MOV  A, DIG4
        MOVC A, @A+DPTR
        MOV  SEG_BYTE, A
        MOV  A, SEG_BYTE
        CALL SHIFT_OUT
        CLR  DIGIT4
        CALL DIG_DELAY
        SETB DIGIT4
        RET

;=============================================================================
; DIG_DELAY � short delay for digit on-time during multiplexing
; Uses only R1 to avoid any conflict with delay subroutines (R3-R7)
;=============================================================================
DIG_DELAY:
        MOV  R1, #0FFH
DIG_DL: DJNZ R1, DIG_DL
        RET

;=============================================================================
; SHIFT_OUT
; Sends 8 bits MSB-first to 74HC595 serially
;
; Uses R0 as bit counter (8 iterations)
; RLC A: rotates A left through carry � bit7 goes into Carry each time
; After 8 shifts, A = 00H (fully shifted out) � that is why SEG_BYTE is needed
;=============================================================================
SHIFT_OUT:
        MOV  R0, #08H
SFT_LP: RLC  A                  ; bit7 ? Carry
        MOV  SER, C             ; send bit to 74HC595 SER pin
        SETB SRCLK              ; clock rising edge: latch bit into shift reg
        CLR  SRCLK              ; clock falling edge: ready for next bit
        DJNZ R0, SFT_LP
        SETB RCLK               ; latch rising edge: shift reg ? output pins
        CLR  RCLK               ; latch falling edge: outputs stable
        RET

;=============================================================================
; PLAY_MELODY � passive buzzer, 3-note done sound
; CPL BUZZER generates square wave at frequency set by inner delay loop
;
; Note 1: C5 ~523Hz ? half period ~956us ? delay loop ~60H iterations
; Note 2: C5 same as note 1
; Note 3: G5 ~784Hz ? half period ~637us ? delay loop ~48H iterations
;
; Uses R4 (note duration), R7 (half period delay)
;=============================================================================
PLAY_MELODY:
        ; Note 1: C5 short
        MOV  R4, #80H
ML_N1:  CPL  BUZZER
        MOV  R7, #60H
        DJNZ R7, $
        DJNZ R4, ML_N1
        CALL DELAY_100MS        ; gap between notes

        ; Note 2: C5 short
        MOV  R4, #80H
ML_N2:  CPL  BUZZER
        MOV  R7, #60H
        DJNZ R7, $
        DJNZ R4, ML_N2
        CALL DELAY_100MS

        ; Note 3: G5 long
        MOV  R4, #0C0H
ML_N3:  CPL  BUZZER
        MOV  R7, #48H
        DJNZ R7, $
        DJNZ R4, ML_N3

        CLR  BUZZER             ; silence
        CALL DELAY_200MS
        RET

;=============================================================================
; DELAY SUBROUTINES (calibrated for 12MHz crystal)
;
; REGISTER MAP � do not reuse these registers in calling code:
;   R0 ? SHIFT_OUT
;   R1 ? DIG_DELAY
;   R2 ? (free)
;   R3 ? DELAY_1S outer loop
;   R4 ? DELAY_500MS outer loop, PLAY_MELODY duration
;   R5 ? DELAY_20MS outer loop, DELAY_100MS outer loop
;   R6 ? DELAY_2MS outer loop
;   R7 ? DELAY_2MS inner loop, PLAY_MELODY half-period
;
; RAM:
;   MUX_CNT (48H) ? UPDATE_7SEG mux loop
;   SEG_BYTE (49H) ? SHOW_Dx temp
;=============================================================================
DELAY_2MS:
        MOV  R6, #0AH
D2_L:   MOV  R7, #0FFH
        DJNZ R7, $
        DJNZ R6, D2_L
        RET

DELAY_20MS:
        MOV  R5, #14H
D20_L:  CALL DELAY_2MS
        DJNZ R5, D20_L
        RET

DELAY_100MS:
        MOV  R5, #05H
D100_L: CALL DELAY_20MS
        DJNZ R5, D100_L
        RET

DELAY_200MS:
        CALL DELAY_100MS
        CALL DELAY_100MS
        RET

DELAY_500MS:
        MOV  R4, #19H
D500_L: CALL DELAY_20MS
        DJNZ R4, D500_L
        RET

DELAY_1S:
        MOV  R3, #32H
D1S_L:  CALL DELAY_20MS
        DJNZ R3, D1S_L
        RET
		
WAIT_1S:

    MOV R3,#50

W1:
    CALL UPDATE_7SEG
    CALL DELAY_2MS
    DJNZ R3,W1

    RET
	
;=============================================================================
; 7-SEGMENT ENCODING TABLE (common cathode, a-g active HIGH)
;
; Segment to bit mapping:
;   bit0 = a ? QA (74HC595 pin 15)
;   bit1 = b ? QB (pin 1)
;   bit2 = c ? QC (pin 2)
;   bit3 = d ? QD (pin 3)
;   bit4 = e ? QE (pin 4)
;   bit5 = f ? QF (pin 5)
;   bit6 = g ? QG (pin 6)
;   bit7 = dp? QH (pin 7)
;=============================================================================
SEG_TABLE:
        DB 3FH  ; 0: a b c d e f   = 0011 1111
        DB 06H  ; 1:   b c         = 0000 0110
        DB 5BH  ; 2: a b   d e   g = 0101 1011
        DB 4FH  ; 3: a b c d     g = 0100 1111
        DB 66H  ; 4:   b c     f g = 0110 0110
        DB 6DH  ; 5: a   c d   f g = 0110 1101
        DB 7DH  ; 6: a   c d e f g = 0111 1101
        DB 07H  ; 7: a b c         = 0000 0111
        DB 7FH  ; 8: a b c d e f g = 0111 1111
        DB 6FH  ; 9: a b c d   f g = 0110 1111

        END